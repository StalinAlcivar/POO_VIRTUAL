/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author hP
 */
public class JavaApplication4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
  Carro carro1 = new Carro("chevrolet",48,4);
  System.out.println("marca: "+carro1.marca+" "+"kilometraje: "+carro1.kilometraje);
  carro1.abrirPuertas();
  
   Moto moto1 = new Moto("yamaha",15,2); 
   System.out.println("marca: "+moto1.marca+" "+"kilometraje: "+moto1.kilometraje);
   moto1.encederMoto();
    }
     
}
