/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author hP
 */
public abstract class Vehiculo {
    public String marca;
    public int kilometraje; 
    public int ruedas; 
    private String matricula; 

    public Vehiculo(String marca, int kilometraje, int ruedas) {
        this.marca = marca;
        this.kilometraje = kilometraje;
        this.ruedas = ruedas;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

}